object test {

  def main(args: Array[String]): Unit = {

    println("hello")
  }
}
